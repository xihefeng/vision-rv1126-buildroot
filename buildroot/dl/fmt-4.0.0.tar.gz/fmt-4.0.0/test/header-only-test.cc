// Header-only configuration test

#include "fmt/format.h"
