### libglob

This repository contains the OpenBSD implementation of glob(3),
with non-POSIX features like GLOB\_TILDE that are not available
in strict POSIX C libraries (musl).
