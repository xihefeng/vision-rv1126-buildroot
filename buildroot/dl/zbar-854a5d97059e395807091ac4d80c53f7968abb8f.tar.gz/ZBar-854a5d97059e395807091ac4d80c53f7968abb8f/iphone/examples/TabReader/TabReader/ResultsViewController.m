//
//  SecondViewController.m
//  TabReader
//
//  Created by spadix on 5/3/11.
//

#import "ResultsViewController.h"


@implementation ResultsViewController

@synthesize resultImage, resultText;

- (BOOL) shouldAutorotateToInterfaceOrientation: (UIInterfaceOrientation) orient
{
    return(YES);
}

@end
