#!/bin/sh
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/userdata/ffarc/lib/
/userdata/ffarc/bin/rkmedia_vi_arc_rtsp_test_640_360  rtsp://127.0.0.1:8554/main
#/userdata/ffarc/bin/rkmedia_vi_arc_rtsp_test_2688_1520 rtsp://127.0.0.1:8554/main
