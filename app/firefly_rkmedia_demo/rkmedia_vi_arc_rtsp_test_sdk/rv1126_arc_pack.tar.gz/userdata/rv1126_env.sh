#!/bin/sh
source /etc/profile.d/RkEnv.sh
/oem/RkLunch-stop.sh
rm /usr/bin/check_brightness.sh
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/userdata/ffarc/lib/
chmod 755 /userdata/ffarc/bin/rkmedia_vi_arc_rtsp_test_640_360
chmod 755 /userdata/ffarc/bin/register
mkdir /userdata/ffarc/ffarc_tmp/
cp /userdata/test_data/* /userdata/ffarc/ffarc_tmp/
cd /userdata/ffarc/ffarc_tmp/
/userdata/ffarc/bin/register 李四.jpg  王五.jpg  张三.jpg  赵六.jpg
/userdata/EasyDarwin-linux-8.1.0-21102107/easydarwin &
