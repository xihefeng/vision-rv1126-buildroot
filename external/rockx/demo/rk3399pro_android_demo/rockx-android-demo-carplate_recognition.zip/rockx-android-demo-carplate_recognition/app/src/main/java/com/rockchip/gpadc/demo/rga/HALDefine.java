package com.rockchip.gpadc.demo.rga;

public class HALDefine {
    public static final int HAL_PIXEL_FORMAT_RGBA_8888 = 1;
    public static final int HAL_PIXEL_FORMAT_RGBX_8888 = 2;
    public static final int HAL_PIXEL_FORMAT_RGB_888 =	3;
    public static final int HAL_PIXEL_FORMAT_RGB_565 = 4;
    public static final int HAL_PIXEL_FORMAT_BGRA_8888 = 5;
    public static final int HAL_PIXEL_FORMAT_YCrCb_NV12 = 	0x15;	/* YUY2 */
    public static final int HAL_PIXEL_FORMAT_YCRCB_420_SP =  17;

    public static final int HAL_TRANSFORM_FLIP_H = 1; // 0x01
    public static final int HAL_TRANSFORM_FLIP_V = 2; // 0x02
    public static final int HAL_TRANSFORM_ROT_90 = 4; // 0x04
    public static final int HAL_TRANSFORM_ROT_180 = 3; // 0x03
    public static final int HAL_TRANSFORM_ROT_270 = 7; // 0x07
}
