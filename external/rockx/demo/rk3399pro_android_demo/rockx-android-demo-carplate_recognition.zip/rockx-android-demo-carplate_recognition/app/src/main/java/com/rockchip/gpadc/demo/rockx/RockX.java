package com.rockchip.gpadc.demo.rockx;

import android.content.Context;
import android.content.res.AssetManager;
import android.util.Log;

import com.rockchip.gpadc.demo.DetectObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class RockX {

    private static final String TAG = "rockx";

    private static final int ROCKX_MODULE_FACE_DETECTION = 1;
    private static final int ROCKX_MODULE_FACE_LANDMARK_68 = 2;
    private static final int ROCKX_MODULE_FACE_RECOGITION = 3;
    private static final int ROCKX_MODULE_FACE_ANALYZE = 4;
    private static final int ROCKX_MODULE_OBJECT_DETECTION = 5;
    private static final int ROCKX_MODULE_POSE_BODY = 6;
    private static final int ROCKX_MODULE_POSE_FINGER_21 = 7;
    private static final int ROCKX_MODULE_FACE_LANDMARK_5 = 8;
    private static final int ROCKX_MODULE_HEAD_DETECTION = 9;
    private static final int ROCKX_MODULE_CARPLATE_DETECTION = 10;
    private static final int ROCKX_MODULE_CARPLATE_ALIGN = 11;
    private static final int ROCKX_MODULE_CARPLATE_RECOG = 12;
    private static final int ROCKX_MODULE_OBJECT_TRACK = 13;
    private static final int ROCKX_MODULE_POSE_FINGER_3 = 14;
    private static final int ROCKX_MODULE_FACE_LIVENESS = 15;

    public static final int ROCKX_PIXEL_FORMAT_GRAY8 = 0;
    public static final int ROCKX_PIXEL_FORMAT_RGB888 = 1;
    public static final int ROCKX_PIXEL_FORMAT_BGR888 = 2;

    private String mModelPath;
    private Context mContext;

    private long mRockXPlateDetectionModule;
    private long mRockXCarplateOnetModule;
    private long mRockXCarplateRecogModule;

    public RockX(Context context) {
        mContext = context;
    }

    public void create() {
        mModelPath = installRockxData(mContext);
        mRockXPlateDetectionModule = native_create_rockx_module(mModelPath, ROCKX_MODULE_CARPLATE_DETECTION);
        mRockXCarplateOnetModule = native_create_rockx_module(mModelPath, ROCKX_MODULE_CARPLATE_ALIGN);
        mRockXCarplateRecogModule = native_create_rockx_module(mModelPath, ROCKX_MODULE_CARPLATE_RECOG);
    }

    private String installRockxData(Context context) {
        File rockxDataDir = new File(context.getFilesDir().getAbsolutePath() + "/rockx-data");
        if (rockxDataDir.exists()) {
            Log.d(TAG, String.format("%s already exist", rockxDataDir.getAbsoluteFile()));
            return rockxDataDir.getAbsolutePath();
        }
        Log.d(TAG, String.format("create %s", rockxDataDir.getAbsoluteFile()));
        rockxDataDir.mkdir();
        AssetManager am = context.getAssets();
        try {
            String rockxDataFileList[] = am.list("rockx-data");
            for (String rockxDataFile : rockxDataFileList) {
                Log.d(TAG, String.format("create %s", rockxDataDir + "/" + rockxDataFile));
                InputStream is = am.open("rockx-data/" + rockxDataFile);
                FileOutputStream fos = new FileOutputStream(rockxDataDir + "/" + rockxDataFile);
                byte[] buffer = new byte[1024];
                int byteCount;
                while ((byteCount = is.read(buffer)) != -1) {
                    fos.write(buffer, 0, byteCount);
                }
                fos.flush();
                is.close();
                fos.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
        return rockxDataDir.getAbsolutePath();
    }

    @Override
    protected void finalize() throws Throwable {
        super.finalize();
        native_destroy_rockx_module(mRockXPlateDetectionModule);
        native_destroy_rockx_module(mRockXCarplateOnetModule);
        native_destroy_rockx_module(mRockXCarplateRecogModule);
    }

    public ArrayList<DetectObject> detectCarplate(byte[] inData, int inWidth, int inHeight, int inPixelFmt) {
        ArrayList<DetectObject> detectObjectList = new ArrayList<>();
        native_plate_detect(mRockXPlateDetectionModule, inData, inWidth, inHeight, inPixelFmt, detectObjectList);
        return detectObjectList;
    }


    public Map<String,Float> recogCarplate(byte[] inData, int width, int height, int inPixelFmt,
                                           int left, int right, int top, int bottom ,
                                           byte[] recog_result  , float trans_alignconfidence, float a_t, float a_num, float r_t, float r_num) {

        byte[] alignimg = new byte[40*160*3];
        long starttime;
        long endtime;

        int x1 = left;
        int x2 = right;
        int y1 = top;
        int y2 = bottom;
        if (x1<=1) { x1 = 1; }
        if (x2<=1) { x2 = 1; }
        if (x1>=(width-1)) { x1 = width-1; }
        if (x2>=(width-1)) { x2 = width-1; }
        if (x1>x2) { x1=x2;}
        if (y1<=1) { y1 = 1; }
        if (y2<=1) { y2 = 1; }
        if (y1>=(height-1)) { y1 = height-1; }
        if (y2>=(height-1)) { y2 = height-1; }
        if (y1>y2) { y1=y2; }

        Log.d(TAG, "in align width:"+width+"  height:"+height);

        Log.d(TAG, "in align left:"+x1+"  right:"+x2);
        Log.d(TAG, "in align top:"+y1+"  bottom:"+y2);

        float alignconfidence = 0.0f;

        starttime = System.currentTimeMillis();
        alignconfidence = native_get_aligned_plate(mRockXCarplateOnetModule, inData,width, height, inPixelFmt,
                x1, x2, y1, y2, alignconfidence , alignimg);
        endtime = System.currentTimeMillis();
        a_t+=(endtime-starttime)/1000F;
        a_num++;

        System.gc();

        Map<String,Float> result=new HashMap<>();
        if (alignconfidence < 0) {
            alignimg = null;
            System.gc();
            result.put("alignconfidence",alignconfidence);
            return result;
        }

        if(alignconfidence>0.5) {       //filter the case of single character
            starttime = System.currentTimeMillis();
            float ret = native_get_recog_result(mRockXCarplateRecogModule, alignimg, inPixelFmt, recog_result);
            endtime = System.currentTimeMillis();
            r_t+=(endtime-starttime)/1000F;
            r_num++;
            Log.d(TAG, "current_ average recog time = " + r_t/r_num);

            if (ret < 0) {
                alignimg = null;
                System.gc();
                result.put("alignconfidence",alignconfidence);
                return result;
            }
        }

        System.gc();
        result.put("alignconfidence",alignconfidence);
        result.put("a_t",a_t);
        result.put("a_num",a_num);
        result.put("r_t",r_t);
        result.put("r_num",r_num);
        return result;
    }

    private native long native_create_rockx_module(String modelPath, int module);
    private native void native_destroy_rockx_module(long handle);
    private native int native_plate_detect(long handle, byte[] inData, int inWidth, int inHeight, int inPixelFmt, ArrayList<DetectObject> detectObjectList);
    private native float native_get_aligned_plate(long handle, byte[] inMat,int inWidth, int inHeight,  int inPixelFmt,
                                               int Left, int Right, int Top, int Bottom, float align_confidence,
                                               byte[] aligneddata);
    private native int native_get_recog_result(long handle, byte[] inMat,int inPixelFmt,byte[] recogresult);

    static {
        System.loadLibrary("rknn4j");
    }
}
