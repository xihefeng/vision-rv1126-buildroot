package com.rockchip.gpadc.demo;

import android.content.res.AssetManager;

import java.io.IOException;
import java.util.ArrayList;

public class InferenceResult {

    OutputBuffer mOutputBuffer;
    ArrayList<DetectObject> detectObjects = null;
    private boolean mIsVaild = false;   //是否需要重新计算
    public byte[] img = null;

    public void init(AssetManager assetManager) throws IOException {
        mOutputBuffer = new OutputBuffer();
    }

    public void reset() {
        if (detectObjects != null) {
            detectObjects.clear();
            mIsVaild = true;
        }
    }

    public synchronized void setResult(ArrayList<DetectObject> detectObjects) {
        this.detectObjects = detectObjects;
    }

    public synchronized ArrayList<DetectObject> getResult() {
        return detectObjects;
    }

    public static class OutputBuffer {
        public float[] mLocations;
        public float[] mClasses;
    }

}
