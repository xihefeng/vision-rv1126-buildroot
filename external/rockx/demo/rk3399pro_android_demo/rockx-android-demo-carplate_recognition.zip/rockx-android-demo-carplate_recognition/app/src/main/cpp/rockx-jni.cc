#include "rockx.h"

#include "log.h"
#include "jni.h"
#include <unistd.h>
#include <string.h>
#include <cstdlib>
#include <string>

/*************************************************************************
                        comman function
**************************************************************************/
static char* jstringToChar(JNIEnv* env, jstring jstr) {
    char* rtn = NULL;
    jclass clsstring = env->FindClass("java/lang/String");
    jstring strencode = env->NewStringUTF("utf-8");
    jmethodID mid = env->GetMethodID(clsstring, "getBytes", "(Ljava/lang/String;)[B");
    jbyteArray barr = (jbyteArray) env->CallObjectMethod(jstr, mid, strencode);
    jsize alen = env->GetArrayLength(barr);
    jbyte* ba = env->GetByteArrayElements(barr, JNI_FALSE);

    if (alen > 0) {
        rtn = new char[alen + 1];
        memcpy(rtn, ba, alen);
        rtn[alen] = 0;
    }
    env->ReleaseByteArrayElements(barr, ba, 0);
    return rtn;
}

jobject object_c2j(JNIEnv *env, rockx_object_t *face, int inWidth, int inHeight) {
    jclass cls_DetectObject = env->FindClass("com/rockchip/gpadc/demo/DetectObject");
    jmethodID Face_construct = env->GetMethodID(cls_DetectObject, "<init>", "(FFFFF)V");

    jvalue * args = (jvalue*)malloc(5*sizeof(jvalue));
    args[0].f = (float)face->box.left / inWidth;
    args[1].f = (float)face->box.top / inHeight;
    args[2].f = (float)face->box.right / inWidth;
    args[3].f = (float)face->box.bottom / inHeight;
    args[4].f = face->score;
    LOGI("(%f %f %f %f) %f", args[0].f, args[1].f, args[2].f, args[3].f, args[4].f)
    jobject detectObjectj = env->NewObjectA(cls_DetectObject, Face_construct, args);
     if (args != nullptr) {
         free(args);
     }
    return detectObjectj;
}

int object_array_c2j(JNIEnv *env, rockx_object_array_t *detect_object_array, jobject detectObjectList, int inWidth, int inHeight) {
    jclass cls_ArrayList = env->GetObjectClass(detectObjectList);
    jmethodID ArrayList_add = env->GetMethodID(cls_ArrayList, "add", "(Ljava/lang/Object;)Z");

    for (int i = 0; i < detect_object_array->count; i++) {
        jobject face = object_c2j(env, &(detect_object_array->object[i]), inWidth, inHeight);
        env->CallBooleanMethod(detectObjectList, ArrayList_add, face);
    }
    return 0;
}

/*************************************************************************
                        rockx jni api
**************************************************************************/
extern "C"
JNIEXPORT jlong JNICALL Java_com_rockchip_gpadc_demo_rockx_RockX_native_1create_1rockx_1module
        (JNIEnv *env, jobject obj, jstring modelPath, jint module)
{
    rockx_ret_t ret;

    rockx_handle_t handle;

    char *model_path = jstringToChar(env, modelPath);

    rockx_config_t rockx_configs;
    memset(&rockx_configs, 0, sizeof(rockx_config_t));

    LOGI("rockx_add_config ROCKX_CONFIG_DATA_PATH=%s\n", model_path);

    rockx_add_config(&rockx_configs, (char *)ROCKX_CONFIG_DATA_PATH, model_path);

    ret = rockx_create(&handle, (rockx_module_t)module, &rockx_configs, sizeof(rockx_config_t));
    if (ret != ROCKX_RET_SUCCESS) {
        LOGI("init rockx module %d error %d\n", module, ret);
        return ret;
    }

    return (jlong)handle;
}

extern "C"
JNIEXPORT void JNICALL Java_com_rockchip_gpadc_demo_rockx_RockX_native_1destroy_1rockx_1module
		(JNIEnv *env, jobject obj, jlong handle) {
	rockx_destroy((rockx_handle_t)handle);
}

/*************************************************************************
                        rockx face jni api
**************************************************************************/
extern "C"
JNIEXPORT jint JNICALL Java_com_rockchip_gpadc_demo_rockx_RockX_native_1plate_1detect
        (JNIEnv *env, jobject obj, jlong handle, jbyteArray inData, jint inWidth, jint inHeight, jint inPixelFmt,
         jobject detectObjectList) {

    jboolean inputCopy = JNI_FALSE;
    jbyte* in_data = env->GetByteArrayElements(inData, &inputCopy);

    // initial rockx_image_t variable
    rockx_image_t input_image;
    input_image.width = inWidth;
    input_image.height = inHeight;
    input_image.data = (unsigned char *)in_data;
    input_image.pixel_format = (rockx_pixel_format)inPixelFmt;

    // create rockx_detect_object_array_t for store result
    rockx_object_array_t detect_object_array;
    rockx_object_array_t object_array;
    memset(&object_array, 0, sizeof(rockx_object_array_t));

    // detect face
    rockx_ret_t ret = rockx_carplate_detect((rockx_handle_t)handle, &input_image, &object_array, nullptr);
    if (ret != ROCKX_RET_SUCCESS) {
        LOGE("rockx_face_detect error %d\n", ret);
        return -1;
    }

    object_array_c2j(env, &object_array, detectObjectList, inWidth, inHeight);

    env->ReleaseByteArrayElements(inData, in_data, JNI_ABORT);

    return 0;
}


extern "C"
JNIEXPORT jfloat JNICALL Java_com_rockchip_gpadc_demo_rockx_RockX_native_1get_1aligned_1plate
        (JNIEnv *env, jobject obj, jlong handle, jbyteArray inData,jint ori_width,jint ori_height, jint inPixelFmt,
         jint Left, jint Right, jint Top, jint Bottom,jfloat align_confidence,
         jbyteArray aligneddata) {

    jboolean inputCopy = JNI_FALSE;
    jbyte* in_data = env->GetByteArrayElements(inData, &inputCopy);
    jboolean outputCopy = JNI_FALSE;
    jbyte* out_aligndata = env->GetByteArrayElements(aligneddata, &outputCopy);

    // initial rockx_image_t variable
    rockx_image_t input_image;
    input_image.width = ori_width;
    input_image.height = ori_height;
    input_image.data = (unsigned char *)in_data;
    input_image.pixel_format = (rockx_pixel_format)inPixelFmt;

    /*************** rockx_carplate_fmapping ***************/
    rockx_handle_t carplate_fmapping_handle;

    // create rockx_carplate_align_result_t for store result
    rockx_carplate_align_result_t aligned_result;
    memset(&aligned_result, 0, sizeof(rockx_carplate_align_result_t));

    rockx_rect_t detect_box;
    detect_box.left=Left;
    detect_box.right=Right;
    detect_box.top=Top;
    detect_box.bottom=Bottom;

    // carplate_fmapping_
    rockx_ret_t  ret = rockx_carplate_align((rockx_handle_t)handle, &input_image, &detect_box, &aligned_result);
    if (ret != ROCKX_RET_SUCCESS) {
        LOGE("rockx_carplate_fmapping error %d\n", ret);
        env->ReleaseByteArrayElements(inData, in_data, JNI_ABORT);
        env->ReleaseByteArrayElements(aligneddata, out_aligndata, 0);
        return -1;
    }

    // process result
    align_confidence = aligned_result.confidence;

    memcpy(out_aligndata, aligned_result.aligned_image.data, 3*40*160);

    rockx_image_release(&(aligned_result.aligned_image));

    env->ReleaseByteArrayElements(inData, in_data, JNI_ABORT);
    env->ReleaseByteArrayElements(aligneddata, out_aligndata, 0);

    if(ret<0)
        return ret;
    else
        return align_confidence;
}


extern "C"
JNIEXPORT jint JNICALL Java_com_rockchip_gpadc_demo_rockx_RockX_native_1get_1recog_1result
        (JNIEnv *env, jobject obj, jlong handle, jbyteArray inData,jint inPixelFmt,
         jbyteArray recogresult) {

    jboolean inputCopy = JNI_FALSE;
    jbyte* in_data = env->GetByteArrayElements(inData, &inputCopy);
    jboolean outputCopy = JNI_FALSE;
    jbyte* out_aligndata = env->GetByteArrayElements(recogresult, &outputCopy);

    // initial rockx_image_t variable
    rockx_image_t input_image;
    input_image.width = 160;
    input_image.height = 40;
    input_image.data = (unsigned char *)in_data;
    input_image.pixel_format = (rockx_pixel_format)inPixelFmt;

    /*************** rockx_carplate_fmapping ***************/
    // create rockx_carplate_recog_result_t for store result
    rockx_carplate_recog_result_t recog_result;
    memset(&recog_result, 0, sizeof(rockx_carplate_recog_result_t));

    rockx_ret_t ret = rockx_carplate_recognize((rockx_handle_t)handle, &input_image, &recog_result);
    if (ret != ROCKX_RET_SUCCESS) {
        LOGE("rockx_carplate_recognize error %d\n", ret);
        return -1;
    }

    std::string platename = "";
    for(int i=0; i < recog_result.length; i++) {
        platename += CARPLATE_RECOG_CODE[recog_result.namecode[i]];
    }

    memcpy(out_aligndata, platename.c_str(), platename.length());

    env->ReleaseByteArrayElements(inData, in_data, JNI_ABORT);
    env->ReleaseByteArrayElements(recogresult, out_aligndata, 0);

    return 0;
}
